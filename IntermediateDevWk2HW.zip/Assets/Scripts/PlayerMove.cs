using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    [SerializeField] private float moveSpd = 0.1f;

    private Animator anim;

    private string _currentAnim;
    
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
    }
    
    
    void FixedUpdate()
    {
        _currentAnim = "SharkIdle";
        
        if (Input.GetKey(KeyCode.UpArrow))
        {
            transform.Translate(Vector3.up * moveSpd);
            _currentAnim = "SharkMoveUp";
        } 
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            transform.Translate(Vector3.down * moveSpd);
            _currentAnim = "SharkMoveDown";
        }
        
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.Translate(Vector3.left * moveSpd);
            _currentAnim = "SharkMoveLeft";
        }
        else if(Input.GetKey(KeyCode.RightArrow))
        {
            transform.Translate(Vector3.right * moveSpd);
            _currentAnim = "SharkMoveRight";
        }

        anim.Play(_currentAnim);
    }
}
